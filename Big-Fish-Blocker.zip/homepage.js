const gameMessageClass = '_3_om _3cpq'
const gameTitleClass = '_79d9 _2p_c'

window.onload = function () {
	const chatTabs = document.querySelector('#ChatTabsPagelet')
	const mutationParams = {
		attributes: true,
		characterData: true,
		childList: true,
		subtree: true
	}

	hideInitial(chatTabs);

	var chatTabsObserver = new MutationObserver(mutationCallback)

	chatTabsObserver.observe(chatTabs, mutationParams)
	console.log("Starting Fish Observing")
}

const hideInitial = function (chatTabs) {
	var gameMessages = chatTabs.getElementsByClassName(gameMessageClass);
	Array.from(gameMessages).forEach( (game) => {
		if ((game.getElementsByClassName(gameTitleClass)[0].innerText).includes("Big Fish")) {
			game.style.display = 'none'
		}
	})
	console.log("Initial Fish Hidden")
}

const mutationCallback = function(mutations, me){
	let nodeMutations = []
	Array.from(mutations).forEach((candidate)=>{
		if (candidate.addedNodes.length != 0)
			nodeMutations.push(candidate)
	})
	Array.from(nodeMutations).forEach((node)=>{

		let gameMessages = node.target.getElementsByClassName(gameMessageClass)

		Array.from(gameMessages).forEach((game) => {
			let gameTitle = game.getElementsByClassName(gameTitleClass)

			if (gameTitle[0] != null && (gameTitle[0].innerText).includes('Big Fish')) {
				game.style.display = 'none'
			}
		})
	})
	

}